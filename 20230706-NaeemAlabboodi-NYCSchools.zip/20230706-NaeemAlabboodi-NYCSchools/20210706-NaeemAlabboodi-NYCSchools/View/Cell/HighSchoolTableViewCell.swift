//
//  HighSchoolTableViewCell.swift
//  20210706-NaeemAlabboodi-NYCSchools
//
//  Created by naeem alabboodi on 7/6/21.
//

import UIKit

class HighSchoolTableViewCell: UITableViewCell {
    @IBOutlet weak var NameLabel: UILabel!
    @IBOutlet weak var numberlabel: UILabel!
    
    

}

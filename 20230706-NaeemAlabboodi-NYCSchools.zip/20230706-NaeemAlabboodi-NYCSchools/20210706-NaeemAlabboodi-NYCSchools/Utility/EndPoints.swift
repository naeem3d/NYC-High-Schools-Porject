//
//  EndPoints.swift
//  20230706-NaeemAlabboodi-NYCSchools
//
//  Created by MAC on 08/07/21.
//

import Foundation


struct EndPoints {
    static let baseUrl = "https://data.cityofnewyork.us/resource/s3k6-pzi2.json"
}

//
//  HighSchol.swift
//  20230706-NaeemAlabboodi-NYCSchools
//
//  Created by naeem alabboodi on 7/6/21.
//

import Foundation


struct HighSchoolModel: Decodable {
    let dbn:String
    let schoolName :String
    let totalStudents:String
}

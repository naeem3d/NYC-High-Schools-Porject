//
//  _0230315_NaeemAlabboodi__NYCSchoolsApp.swift
//  20230315-NaeemAlabboodi- NYCSchools
//
//  Created by naeem alabboodi on 3/16/23.
//

import SwiftUI

@main
struct _0230315_NaeemAlabboodi__NYCSchoolsApp: App {
    var body: some Scene {
        WindowGroup {
            NYC_Schools_Names()
        }
    }
}

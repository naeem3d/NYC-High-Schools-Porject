//
//  NYC_Schools_Names.swift
//  NYC_Schools
//
//  Created by naeem alabboodi on 3/15/23.
//https://github.com/naeem3d/NYC-High-Schools-Porject.git

import SwiftUI

struct NYC_Schools_Names: View {
    @StateObject var vm = NYC_Schools_NamesViewModel()
    @State var satScores: SchoolsDetails?
    var body: some View {
        NavigationStack {
            List {
                
                ForEach(vm.schoolsNames ) { school in
                    NavigationLink {
                        
                        
                        VStack {
                            VStack {
                                Text(school.id)
                                    .foregroundColor(.red)
                                    .bold()
                                Text(school.schoolName)
                                    .multilineTextAlignment(.center)
                            }
                            .padding()
                            .foregroundColor(.blue)
                            .font(.system(size: 20))
                            
                            Divider()
                            DisplaySAT_Scores(schoolName:school.schoolName)
                        }
                    } label: {
                        HStack {
                            Text("\(school.id)")
                                .foregroundColor(.red)
                                .bold()
                                .multilineTextAlignment(.leading)
                                .padding()
                            Text(" : \(school.schoolName)")
                                .font(.system(size: 15))
                                .foregroundColor(.blue)
                                .bold()
                        }
                    }
                    
                    
                }
            }
            
            .navigationTitle("NYC High Schools")
        }
    }
}

struct NYC_Schools_Names_Previews: PreviewProvider {
    static var previews: some View {
        NYC_Schools_Names()
    }
}

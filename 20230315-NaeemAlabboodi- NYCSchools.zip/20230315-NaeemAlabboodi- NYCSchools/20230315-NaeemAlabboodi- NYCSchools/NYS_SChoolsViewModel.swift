//
//  NYS_SChoolsViewModel.swift
//  NYC_Schools
//
//  Created by naeem alabboodi on 3/15/23.
//

import Foundation

class NYC_Schools_NamesViewModel: ObservableObject {
    @Published var schoolsNames: [NYC_SchoolsNames] = []
    @Published var schoolDetails : SchoolsDetails? = nil
    @Published var schoolName : String = "BARUCH COLLEGE CAMPUS HIGH SCHOOL"
    
    init() {
        getSchoolsNames()
    }
    func getSchoolsNames() {
        guard let url = URL(string: "https://data.cityofnewyork.us/resource/s3k6-pzi2.json") else {return }
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data else {
                print("no data ")
                return
            }
            guard error == nil else {
                print("Error:\(String(describing: error))")
                return
            }
            guard response is HTTPURLResponse else {
                print("Invalid resposne \(String(describing: response))")
                return
            }
            print("SUCCESSFUL")
            print(data)
            let jsonString = String(data: data, encoding: .utf8)
//                        print(jsonString!)
            
            guard  let newPost = try? JSONDecoder().decode([NYC_SchoolsNames].self, from: data) else {return}
            DispatchQueue.main.async { [weak self] in
                self?.schoolsNames = newPost
            }
        }
        .resume()
    }
    
    
    func getDetailsForSchool(SchoolName: String) {
        let schoolNameT = SchoolName
        let schoolName2 = schoolNameT.replacingOccurrences(of: " ", with: "%20")
        let name = "https://data.cityofnewyork.us/resource/f9bf-2cp4.json?school_name=\(schoolName2)"
        
        guard let url = URL(string: name) else {return }
        // Make an API request to get the SAT scores for the selected school
        URLSession.shared.dataTask(with: url) { data, response, error in
            guard let data = data else {
                print("no data ")
                return
            }
            guard error == nil else {
                print("Error:\(String(describing: error))")
                return
            }
            guard response is HTTPURLResponse else {
                print("Invalid resposne \(String(describing: response))")
                return
            }
            print("SUCCESSFUL")
            print(data)
            let jsonString = String(data: data, encoding: .utf8)
            print("the new scores is: \(jsonString!)")
            
            guard  let newPost = try? JSONDecoder().decode([SchoolsDetails].self, from: data) else {return}
            DispatchQueue.main.async { [weak self] in
                self?.schoolDetails = newPost.first
                
                //                print("the new sschoolDetails is: \( self?.schoolDetails! ?? example")
                
            }
        }
        .resume()
    }
}

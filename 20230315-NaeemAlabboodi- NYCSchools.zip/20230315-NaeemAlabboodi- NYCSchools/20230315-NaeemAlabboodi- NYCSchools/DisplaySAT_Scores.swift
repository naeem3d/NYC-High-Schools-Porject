//
//  DisplaySAT_Scores.swift
//  NYC_Schools
//
//  Created by naeem alabboodi on 3/15/23.
//

import SwiftUI

struct DisplaySAT_Scores: View {
    @StateObject var  vm = NYC_Schools_NamesViewModel()
    var schoolName: String
     var schoolwithNewName : SchoolsDetails?
    var body: some View {
       
        NavigationStack {
           
            VStack (alignment: .leading){
               
                HStack {
                    Text( "MathAvgScore: ")
                    Spacer()
                    Text("\(vm.schoolDetails?.satMathAvgScore ?? "Unknown")")
                        .frame(width: 210, alignment: .leading)
                        .foregroundColor(.mint)
                }
                .padding(10)
                HStack {
                    Text( "TestTakers:")
                    Spacer()
                    Text( "\(vm.schoolDetails?.numOfSatTestTakers ?? "Unknown")")
                        .frame(width: 210, alignment: .leading)
                        .foregroundColor(.mint)
                }
                .padding(10)
                HStack {
                    Text( "ReadingAvgScore:")
                    Spacer()
                    Text( "\(vm.schoolDetails?.satCriticalReadingAvgScore ?? "Unknown")")
                        .frame(width: 210, alignment: .leading)
                        .foregroundColor(.mint)
                }
                .padding(10)
                HStack {
                    Text( "RitingAvgScore:")
                    Spacer()
                    Text("\(vm.schoolDetails?.satWritingAvgScore ?? "Unknown")")
                        .frame(width: 210, alignment: .leading)
                        .foregroundColor(.mint)
                    
                }
                .padding(10)
              Spacer()
                

            }
       
            .onAppear {
            print("the newSchol name is : \(schoolName.uppercased())")
                vm.getDetailsForSchool(SchoolName:schoolName.uppercased())
               
              
             
                
            }
            
        }
    }
        
}

struct DisplaySAT_Scores_Previews: PreviewProvider {
    static var previews: some View {
        DisplaySAT_Scores(schoolName: "unknow")
    }
}
